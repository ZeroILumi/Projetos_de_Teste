# Zero_ILumi_Calculadora_Package

Description. 
The package Zero_ILumi_Calculadora_Package is used to:

​		Calculadora_Completa:

​			- Perform all arithmetic calculations 

​		Arithmetic_Operations:

​			- Isolated arithmetic operations to be performed

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install Zero_ILumi_Calculadora_Package

```bash
pip install Zero_ILumi_Calculadora_Package
```

## Usage

```python
from Zero_ILumi_Calculadora_Package.Calculadora.Calculadora_Completa.Calcular import Calculadora
Calculadora()
```

## Author

Zero ILumi

## License

[MIT](https://choosealicense.com/licenses/mit/)