def multiplicar(valor1, valor2):
    resultado = valor1 * valor2
    return 'A Multiplicação:' \
           ' {valor1} x {valor2} = {resultado}' \
           ''.format(valor1=valor1,
                     valor2=valor2,
                     resultado=resultado)
